new Vue({
  el: '#app',
  data: {
    message: '',
    message2: '',
  },
  methods: {
     
    
  },
})